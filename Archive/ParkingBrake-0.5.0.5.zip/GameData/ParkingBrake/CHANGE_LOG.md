# Parking Break :: Change Log

* 2025-1129: 0.5.0.5 (LisiasT) for KSP >= 1.3
	+ Works around a Unity's idiosyncrasy. (damn)
	+ Closes issues:
		- [#3](https://github.com/net-lisias-ksp/ParkingBrake/issues/3) "Parking brake disengaged" message repeated ad nauseaum
* 2025-1112: 0.5.0.4 (LisiasT) for KSP >= 1.3
	+ Fixes a borkage on the project's dependencies configuration.
	+ Fixes a mishap trying to run the PB modules while on Editor (where it has absolutely no business). Thanks to [pipai](https://forum.kerbalspaceprogram.com/profile/210870-pipai/) for the tip!
	+ Fixes a mishap on `PAW` when loading the savegame (or the vessel getting out of rails)
* 2025-1112: 0.5.0.3 (LisiasT) for KSP >= 1.3
	+ ***DITCHED*** because I made a new release on the same day.
* 2025-1101: 0.5.0.2 (LisiasT) for KSP >= 1.3
	+ Promotes 0.5.0.1 to RELEASE
* 2025-0628: 0.5.0.1 (LisiasT) for KSP >= 1.3 BETA
	+ Specialised behaviour for each `VesselType`:
		- Base
			- Unconditional Auto Engage in all circumstances if the Parking Brake is enabled
			- Never disengages unless the Normal Brakes is deactivated
			- Convenient for... Bases! :)
		- EVA / ROVER:
			- Only engages if the vessel is pretty slow or plain halted.
			- Never disengages automatically.
			- Turning off the Normal Brakes will deactivate it.
			- Prevents KSP from disengaging the Parking Brakes by side effect of physics easyning or similar device to prevent RUDs when loading/switching scenes.
		- Everything else:
			- Only engages if the vessel is pretty slow or plain halted.
			- Disengages automatically if the vessel is not grounded.
			- Turning off the Normal Brakes will deactivate it.
	+ Known Issues: I possibly need to implement something for (water) Ships.
	+ Reworks Issues:
		- [#1](https://github.com/net-lisias-ksp/ParkingBrake/issues/1) Rework the auto-disengage / Implement an auto-engage
* 2024-1006: 0.5.0.0 (LisiasT) for KSP >= 1.3
	+ Initial version under LisiasT's stewardship.
	+ Removing `KSPe` from the dependencies for while.
	+ Removing the `vendor` thingy, as I'm now the official maintainer.
		- Moving back to `GameData` so.
* 2021-1029: 0.4.4.1 (LisiasT) for KSP >= 1.3.0
	+ Recompiling (**hate** this word) to KSPe v2.4
	+ Bumping version to catch up upstream's
* 2021-0306: 0.4.2.1 (LisiasT) for KSP >= 1.3.0
	+ Backport down to KSP 1.3.0
	+ Adding PT-BR localisation
	+ Adding KSPe facilities
	+ Moving the thing to `GameData/net.lisias.ksp` hierarchy.
* 2021-0306: 0.4.2 (Maja) for KSP 1.11.1
	+ Changes
		- Parking brake is disengaged when vessel starts to fly
		- Parking brake is disengaged when you switch off brakes
		- Parking brake added to external command seat
* 2021-0301: 0.4.1 (Maja) for KSP 1.11.1
	+ Changes
		- Russian localization by kovakthemost
* 2021-0207: 0.4.0 (Maja) for KSP 1.11.1
	+ Changes
		- KSP 1.11.1 compatibility
* 2020-0720: 0.3.0 (Maja) for KSP 1.10.1
	+ Changes
		- KSP 1.10 compatibility
* 2019-1020: 0.2.0 (Maja) for KSP 1.8.1
	+ Changes
		- KSP 1.8 compatibility
* 2019-0603: 0.1.2 (Maja) for KSP 1.7.3
	+ Changes
		- KSP 1.7.1 compatibility
* 2019-0428: 0.1.1 (Maja) for KSP 1.7.0
	+ Changes
		- KSP 1.7 compatibility
* 2018-1127: 0.1.0.2 (Maja) for KSP 1.5.1 PRE-RELEASE
	+ Just for testing purposes
* 2018-1126: 0.1.0.1 (Maja) for KSP 1.5.1
	+ Speed limit increased to 0.25 m/s
* 2018-1125: 0.1.0 (Maja) for KSP 1.5.1
	+ Initial release
