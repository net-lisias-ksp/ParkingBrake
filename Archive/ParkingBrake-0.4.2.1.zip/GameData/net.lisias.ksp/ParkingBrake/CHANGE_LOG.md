# Parking Break :: Change Log

* 2021-0306: 0.4.2.1 (LisiasT) for KSP >= 1.3.0
	+ Backport down to KSP 1.3.0
	+ Adding PT-BR localisation
	+ Adding KSPe facilities
	+ Moving the thing to `GameData/net.lisias.ksp` hierarchy.
* 2021-0306: 0.4.2 (Maja) for KSP 1.11.1
	+ Changes
		- Parking brake is disengaged when vessel starts to fly
		- Parking brake is disengaged when you switch off brakes
		- Parking brake added to external command seat
* 2021-0301: 0.4.1 (Maja) for KSP 1.11.1
	+ Changes
		- Russian localization by kovakthemost
* 2021-0207: 0.4.0 (Maja) for KSP 1.11.1
	+ Changes
		- KSP 1.11.1 compatibility
* 2020-0720: 0.3.0 (Maja) for KSP 1.10.1
	+ Changes
		- KSP 1.10 compatibility
* 2019-1020: 0.2.0 (Maja) for KSP 1.8.1
	+ Changes
		- KSP 1.8 compatibility
* 2019-0603: 0.1.2 (Maja) for KSP 1.7.3
	+ Changes
		- KSP 1.7.1 compatibility
* 2019-0428: 0.1.1 (Maja) for KSP 1.7.0
	+ Changes
		- KSP 1.7 compatibility
* 2018-1127: 0.1.0.2 (Maja) for KSP 1.5.1 PRE-RELEASE
	+ Just for testing purposes
* 2018-1126: 0.1.0.1 (Maja) for KSP 1.5.1
	+ Speed limit increased to 0.25 m/s
* 2018-1125: 0.1.0 (Maja) for KSP 1.5.1
	+ Initial release
